/* =========================================================================
 * 歌曲管理 —— tool.js（vanilla，无 CDN 依赖，可离线）
 *
 * 三个标签页 + 一个高级设置弹层：
 *
 *   一、重命名
 *      POST /renamemusic   {old, new, update_title}
 *      后端会同步磁盘文件、all_music、tag cache、所有歌单引用，
 *      并重建 music_list（面板/播放实际用的列表）。
 *
 *   二、专辑管理
 *      GET  /playlistnames                  列自定义歌单
 *      GET  /playlistmusics?name=…          歌单里的歌
 *      POST /playlistadd        {name}      建空专辑
 *      POST /playlistupdatemusic{name,music_list}  整体替换专辑歌曲
 *      POST /playlistdel        {name}      删专辑（只删歌单，不碰音频）
 *
 *   三、自动分类
 *      读 /musiclist 的「所有歌曲」，对每个歌名按 "歌名-歌手" 解析歌手
 *      （第三段起忽略）；含 "/" 的多作者归「多作者，待分类」，
 *      解析不出的归「未知歌手」。界面可逐条改歌手，确认后：
 *        POST /playlistadd        {name}
 *        POST /playlistaddmusic   {name, music_list}
 *        POST /api/music-mgr/album/save   {album, auto:true, songs}
 *      追加式：已存在的专辑不覆盖，只把缺的歌补进去。
 *
 *   高级设置（⚙）
 *      GET  /api/music-mgr/albums           列记录
 *      POST /api/music-mgr/album/delete     {album, delete_playlist}
 *      只删记录（可选连歌单一起删）；**绝不删音频文件**。
 *
 * 依赖后端 music-manager 补丁（/renamemusic、/api/music-mgr/*）。
 *      未装则 404 → 页面给明确提示（不是网络故障）。
 *      其余用到的是官方现成端点。
 *
 * 鉴权：与 /musiclist 同由 verification 会话保护；401/403 给登录入口。
 * ========================================================================= */
(function () {
  "use strict";

  var U = {
    musiclist: "/musiclist",
    rename: "/renamemusic",
    playlistnames: "/playlistnames",
    playlistmusics: "/playlistmusics",
    playlistadd: "/playlistadd",
    playlistaddmusic: "/playlistaddmusic",
    playlistupdatemusic: "/playlistupdatemusic",
    playlistdel: "/playlistdel",
    refreshlist: "/api/music/refreshlist",
    albums: "/api/music-mgr/albums",
    albumSave: "/api/music-mgr/album/save",
    albumDelete: "/api/music-mgr/album/delete",
    auth: "/static/default/index.html"
  };

  var SPECIAL_MULTI = "多作者，待分类";
  var SPECIAL_UNKNOWN = "未知歌手";

  /* ==================== 通用工具 ==================== */

  function $(id) { return document.getElementById(id); }

  function apiReq(method, url, body) {
    var opts = {
      method: method,
      headers: { Accept: "application/json" },
      credentials: "same-origin"
    };
    if (body !== undefined) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    return fetch(url, opts).then(function (res) {
      if (res.status === 401 || res.status === 403) {
        var e = new Error("auth"); e.auth = true; throw e;
      }
      if (res.status === 404) {
        var e2 = new Error("not-implemented"); e2.notImplemented = true; throw e2;
      }
      if (!res.ok) throw new Error("HTTP " + res.status);
      return res.text().then(function (t) {
        if (!t) return "";
        try { return JSON.parse(t); } catch (x) { return t; }
      });
    });
  }

  function setStatus(el, kind, text, retry) {
    el.hidden = false;
    el.className = "mm-status mm-status-" + kind;
    el.textContent = text || "";
    var old = el.querySelector("button.mm-retry");
    if (old) old.remove();
    if (retry) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "mm-btn mm-retry";
      b.textContent = "重试";
      b.addEventListener("click", retry);
      el.appendChild(b);
    }
  }
  function clearStatus(el) { el.hidden = true; el.textContent = ""; }

  function authPrompt(el) {
    setStatus(el, "error", "鉴权未通过 / 会话已失效（401/403）。本页需要已登录的会话。");
    var b = document.createElement("button");
    b.type = "button";
    b.className = "mm-btn";
    b.textContent = "触发一次登录后返回";
    b.addEventListener("click", function () { window.location.href = U.auth; });
    el.appendChild(b);
  }

  function notImpl(el, what) {
    setStatus(el, "error",
      "后端返回 404：" + what + "。需要先在容器里打 music-manager 补丁。");
  }

  function handleErr(el, err, retry, what) {
    if (err && err.auth) { authPrompt(el); return; }
    if (err && err.notImplemented) { notImpl(el, what || "该端点"); return; }
    setStatus(el, "error",
      "请求失败：" + (err && err.message ? err.message : "网络错误"), retry);
  }

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  /* ==================== 标签页切换 ==================== */

  var tabs = document.querySelectorAll(".mm-tab");
  Array.prototype.forEach.call(tabs, function (t) {
    t.addEventListener("click", function () {
      Array.prototype.forEach.call(tabs, function (x) {
        x.classList.toggle("mm-tab-active", x === t);
      });
      ["rename", "album", "auto"].forEach(function (name) {
        $("pane-" + name).hidden = (name !== t.dataset.tab);
      });
    });
  });

  /* 歌曲名 -> 歌手（按 "歌名-歌手[-系列]" 解析，第三段起忽略） */
  function parseArtist(name) {
    var parts = String(name).split("-");
    if (parts.length < 2) return "";
    return parts[1].trim();     // 第 2 段是歌手；第 3 段起是系列，忽略
  }
  function groupForArtist(artist) {
    if (!artist) return SPECIAL_UNKNOWN;
    if (artist.indexOf("/") !== -1) return SPECIAL_MULTI;
    return artist;
  }

  /* ==================== 一、重命名 ==================== */

  var rnAll = [];       // 全部本地歌名
  var rnCurrent = null; // 正在改的歌名

  var rnStatus = $("rn-status");
  var rnList = $("rn-list");
  var rnFilter = $("rn-filter");
  var rnEditor = $("rn-editor");
  var rnResult = $("rn-result");

  function loadSongs(retry) {
    clearStatus(rnStatus);
    rnEditor.hidden = true;
    rnList.innerHTML = "";
    rnList.appendChild(el("li", "mm-loading", "加载中…"));

    apiReq("GET", U.musiclist).then(function (data) {
      var songs = [];
      if (data && data["所有歌曲"]) {
        songs = data["所有歌曲"];
      } else if (data && data["全部"]) {
        songs = data["全部"];
      } else if (data && typeof data === "object") {
        // 兜底：把所有名字合起来
        Object.keys(data).forEach(function (k) {
          if (Array.isArray(data[k])) songs = songs.concat(data[k]);
        });
      }
      // 去重
      var seen = {};
      rnAll = songs.filter(function (s) {
        if (seen[s]) return false;
        seen[s] = true; return true;
      }).sort(function (a, b) { return a.localeCompare(b, "zh"); });

      paintSongs(rnFilter.value);
    }).catch(function (err) {
      rnList.innerHTML = "";
      handleErr(rnStatus, err, function () { loadSongs(true); }, "/musiclist");
    });
  }

  function paintSongs(filter) {
    rnList.innerHTML = "";
    var f = (filter || "").trim().toLowerCase();
    var items = f ? rnAll.filter(function (s) {
      return s.toLowerCase().indexOf(f) !== -1;
    }) : rnAll;

    if (!items.length) {
      rnList.appendChild(el("li", "mm-empty", rnAll.length ? "没有匹配的歌曲。" : "本地没有歌曲。"));
      return;
    }
    items.forEach(function (name) {
      var li = el("li", "mm-item");
      var btn = el("button", "mm-song");
      btn.type = "button";
      btn.appendChild(el("span", "mm-song-name", name));
      btn.addEventListener("click", function () { openEditor(name); });
      li.appendChild(btn);
      rnList.appendChild(li);
    });
  }

  function openEditor(name) {
    rnCurrent = name;
    clearStatus(rnResult);
    $("rn-old").textContent = name;
    $("rn-new").value = name;
    $("rn-uptitle").checked = true;
    rnEditor.hidden = false;
    $("rn-new").focus();
    $("rn-new").select();
    rnEditor.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  function doRename() {
    if (!rnCurrent) return;
    var newName = ($("rn-new").value || "").trim();
    if (!newName) {
      setStatus(rnResult, "error", "新歌名不能为空。");
      return;
    }
    if (newName === rnCurrent) {
      setStatus(rnResult, "warn", "新旧名称相同，无需修改。");
      return;
    }

    var saveBtn = $("rn-save");
    saveBtn.disabled = true;
    clearStatus(rnResult);
    setStatus(rnResult, "info", "正在重命名并重建列表…");

    apiReq("POST", U.rename, {
      old: rnCurrent,
      new: newName,
      update_title: $("rn-uptitle").checked
    }).then(function (data) {
      var st = (data && data.status) || "";
      var detail = (data && data.detail) || "";
      if (st === "ok") {
        var extra = "";
        if (data.playlists_updated && data.playlists_updated.length) {
          extra = "；已同步歌单：" + data.playlists_updated.join("、");
        }
        setStatus(rnResult, "ok",
          "已改名：" + rnCurrent + " → " + newName + extra + "。列表已重建。");
        rnCurrent = newName;
        $("rn-old").textContent = newName;
        loadSongs();
      } else {
        var map = {
          not_found: "找不到这首歌（可能已被改名或删除）",
          web_music: "网络音乐不能改名",
          name_exists: "已存在同名歌曲",
          file_exists: "磁盘上已存在同名文件",
          file_missing: "磁盘上找不到该文件",
          rename_failed: "改文件失败",
          partial: "文件改了，但内存同步失败"
        };
        setStatus(rnResult, "error", (map[st] || "未成功") + (detail ? "：" + detail : ""));
      }
    }).catch(function (err) {
      handleErr(rnResult, err, doRename, "/renamemusic");
    }).then(function () {
      saveBtn.disabled = false;
    });
  }

  $("rn-reload").addEventListener("click", function () { loadSongs(true); });
  rnFilter.addEventListener("input", function () { paintSongs(rnFilter.value); });
  $("rn-save").addEventListener("click", doRename);
  $("rn-cancel").addEventListener("click", function () {
    rnEditor.hidden = true; rnCurrent = null;
  });

  /* ==================== 二、专辑管理 ==================== */

  var alStatus = $("al-status");
  var alList = $("al-list");
  var alEditor = $("al-editor");
  var alResult = $("al-result");

  var alAlbums = [];    // [{name, auto, count}]
  var alCurrent = null; // 当前编辑的专辑名
  var alSelected = {};  // 歌曲名 -> true
  var alAllSongs = [];

  function loadAlbums(retry) {
    clearStatus(alStatus);
    alEditor.hidden = true;
    alList.innerHTML = "";
    alList.appendChild(el("div", "mm-loading", "加载中…"));

    Promise.all([
      apiReq("GET", U.playlistnames).catch(function (e) {
        if (e && e.notImplemented) throw e;
        return { names: [] };
      }),
      apiReq("GET", U.albums).catch(function (e) {
        if (e && e.notImplemented) return { albums: [] };
        throw e;
      }).catch(function () { return { albums: [] }; })
    ]).then(function (res) {
      var names = (res[0] && res[0].names) || [];
      var records = (res[1] && res[1].albums) || [];
      var autoMap = {};
      records.forEach(function (r) { autoMap[r.album] = true; });

      alAlbums = names.map(function (n) {
        return { name: n, auto: !!autoMap[n] };
      });
      paintAlbums();
      if (!alAlbums.length) {
        setStatus(alStatus, "info", "还没有专辑。可在「自动分类」里按歌手批量创建，或点上方「新建空专辑」。");
      }
    }).catch(function (err) {
      alList.innerHTML = "";
      handleErr(alStatus, err, function () { loadAlbums(true); }, "/playlistnames");
    });
  }

  function paintAlbums() {
    alList.innerHTML = "";
    if (!alAlbums.length) return;
    alAlbums.forEach(function (a) {
      var card = el("button", "mm-album");
      card.type = "button";
      card.appendChild(el("div", "mm-album-name", a.name));
      card.appendChild(el("div", "mm-album-sub", a.auto ? "自动分类创建" : "手动创建"));
      card.addEventListener("click", function () { openAlbum(a.name); });
      alList.appendChild(card);
    });
  }

  function openAlbum(name) {
    alCurrent = name;
    clearStatus(alResult);
    $("al-title").textContent = name;
    alSelected = {};
    alEditor.hidden = false;
    alEditor.scrollIntoView({ behavior: "smooth", block: "nearest" });

    // 标签
    var tags = $("al-tags");
    tags.innerHTML = "";
    tags.appendChild(el("span", "mm-tag", name));

    // 取歌单现有歌曲 + 全部歌曲
    Promise.all([
      apiReq("GET", U.playlistmusics + "?name=" + encodeURIComponent(name))
        .catch(function () { return { musics: [] }; }),
      apiReq("GET", U.musiclist).catch(function () { return {}; })
    ]).then(function (res) {
      var cur = (res[0] && res[0].musics) || [];
      cur.forEach(function (s) { alSelected[s] = true; });

      var data = res[1] || {};
      var songs = data["所有歌曲"] || data["全部"] || [];
      var seen = {};
      alAllSongs = songs.filter(function (s) {
        if (seen[s]) return false; seen[s] = true; return true;
      }).sort(function (a, b) { return a.localeCompare(b, "zh"); });

      paintAlbumSongs($("al-song-filter").value);
    }).catch(function (err) {
      handleErr(alResult, err, function () { openAlbum(name); }, "读取专辑歌曲");
    });
  }

  function paintAlbumSongs(filter) {
    var box = $("al-songs");
    box.innerHTML = "";
    var f = (filter || "").trim().toLowerCase();
    var items = f ? alAllSongs.filter(function (s) {
      return s.toLowerCase().indexOf(f) !== -1;
    }) : alAllSongs;

    if (!items.length) {
      box.appendChild(el("li", "mm-empty", alAllSongs.length ? "没有匹配的歌曲。" : "本地没有歌曲。"));
      return;
    }
    items.forEach(function (name) {
      var li = el("li", "mm-item");
      var row = el("label", "mm-song");
      var cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = !!alSelected[name];
      cb.addEventListener("change", function () {
        if (cb.checked) alSelected[name] = true; else delete alSelected[name];
      });
      row.appendChild(cb);
      row.appendChild(el("span", "mm-song-name", name));
      li.appendChild(row);
      box.appendChild(li);
    });
  }

  function saveAlbum() {
    if (!alCurrent) return;
    var songs = Object.keys(alSelected).sort(function (a, b) {
      return a.localeCompare(b, "zh");
    });

    var btn = $("al-save");
    btn.disabled = true;
    clearStatus(alResult);
    setStatus(alResult, "info", "正在保存专辑…");

    // 先确保歌单存在（已存在会返回 Add failed，无妨），再整体替换歌曲
    apiReq("POST", U.playlistadd, { name: alCurrent })
      .catch(function () { return null; })
      .then(function () {
        return apiReq("POST", U.playlistupdatemusic,
          { name: alCurrent, music_list: songs });
      })
      .then(function () {
        setStatus(alResult, "ok", "已保存：" + alCurrent + "，共 " + songs.length + " 首。");
        loadAlbums();
      })
      .catch(function (err) {
        handleErr(alResult, err, saveAlbum, "保存专辑");
      })
      .then(function () { btn.disabled = false; });
  }

  $("al-reload").addEventListener("click", function () { loadAlbums(true); });
  $("al-new").addEventListener("click", function () {
    var name = window.prompt("新专辑名称（也就是歌单名）：");
    if (!name || !name.trim()) return;
    apiReq("POST", U.playlistadd, { name: name.trim() }).then(function () {
      loadAlbums();
    }).catch(function (err) {
      handleErr(alStatus, err, null, "新建专辑");
    });
  });
  $("al-song-filter").addEventListener("input", function () {
    paintAlbumSongs($("al-song-filter").value);
  });
  $("al-save").addEventListener("click", saveAlbum);
  $("al-close").addEventListener("click", function () {
    alEditor.hidden = true; alCurrent = null;
  });

  /* ==================== 三、自动分类 ==================== */

  var auStatus = $("au-status");
  var auResult = $("au-result");
  var auGroups = $("au-groups");
  var auData = [];     // [{name, artist, group}] 逐首的解析结果

  function analyze() {
    clearStatus(auStatus);
    clearStatus(auResult);
    auGroups.innerHTML = "";
    auGroups.appendChild(el("div", "mm-loading", "分析中…"));
    $("au-analyze").disabled = true;

    apiReq("GET", U.musiclist).then(function (data) {
      var songs = (data && (data["所有歌曲"] || data["全部"])) || [];
      var seen = {};
      songs = songs.filter(function (s) {
        if (seen[s]) return false; seen[s] = true; return true;
      }).sort(function (a, b) { return a.localeCompare(b, "zh"); });

      auData = songs.map(function (name) {
        var artist = parseArtist(name);
        return { name: name, artist: artist, group: groupForArtist(artist) };
      });
      paintGroups();

      var checked = {};
      auData.forEach(function (d) { checked[d.group] = true; });
      var n = Object.keys(checked).length;
      setStatus(auStatus, "ok",
        "共 " + auData.length + " 首，解析出 " + n + " 个分类。可逐条改歌手，确认后创建。");
    }).catch(function (err) {
      auGroups.innerHTML = "";
      handleErr(auStatus, err, analyze, "/musiclist");
    }).then(function () {
      $("au-analyze").disabled = false;
    });
  }

  function paintGroups() {
    auGroups.innerHTML = "";

    // 按 group 聚合
    var order = [];
    var byGroup = {};
    auData.forEach(function (d, i) {
      if (!byGroup[d.group]) { byGroup[d.group] = []; order.push(d.group); }
      byGroup[d.group].push(i);
    });

    // 特殊组排后面
    order.sort(function (a, b) {
      var sa = (a === SPECIAL_MULTI || a === SPECIAL_UNKNOWN) ? 1 : 0;
      var sb = (b === SPECIAL_MULTI || b === SPECIAL_UNKNOWN) ? 1 : 0;
      if (sa !== sb) return sa - sb;
      return a.localeCompare(b, "zh");
    });

    order.forEach(function (g) {
      var idxs = byGroup[g];
      var box = el("div", "mm-group");

      var head = el("div", "mm-group-head");
      var cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = true;
      cb.dataset.group = g;
      cb.addEventListener("change", function () {
        // 组勾选 = 该组全体歌的归属开关（影响创建时是否处理这组）
        cb.dataset.checked = cb.checked ? "1" : "0";
        updateCreateBtn();
      });
      cb.dataset.checked = "1";
      head.appendChild(cb);
      head.appendChild(el("span", "mm-group-name mm-group-check", g));
      if (g === SPECIAL_MULTI || g === SPECIAL_UNKNOWN) {
        head.appendChild(el("span", "mm-special", "需手动处理"));
      }
      head.appendChild(el("span", "mm-group-count", idxs.length + " 首"));
      box.appendChild(head);

      var songs = el("div", "mm-group-songs");
      idxs.forEach(function (i) {
        var d = auData[i];
        var row = el("div", "mm-gsong");
        var inp = document.createElement("input");
        inp.type = "text";
        inp.className = "mm-artist-input";
        inp.value = d.artist;
        inp.placeholder = "（空=未知歌手）";
        inp.addEventListener("change", function () {
          d.artist = inp.value.trim();
          var ng = groupForArtist(d.artist);
          if (ng !== d.group) {
            d.group = ng;
            paintGroups();   // 归属变了，重新分组
          }
        });
        row.appendChild(el("span", "mm-gsong-name", d.name));
        row.appendChild(inp);
        songs.appendChild(row);
      });
      box.appendChild(songs);
      auGroups.appendChild(box);

      updateCreateBtn();
    });
  }

  function updateCreateBtn() {
    $("au-create").disabled = auData.length === 0;
    $("au-selall").disabled = auData.length === 0;
    $("au-selnone").disabled = auData.length === 0;
  }

  function setAllGroups(checked) {
    Array.prototype.forEach.call(
      auGroups.querySelectorAll("input[type=checkbox][data-group]"),
      function (cb) {
        cb.checked = checked;
        cb.dataset.checked = checked ? "1" : "0";
      });
    updateCreateBtn();
  }

  function createSelected() {
    if (!auData.length) return;

    // 收集"被勾选的组"
    var wanted = {};
    Array.prototype.forEach.call(
      auGroups.querySelectorAll("input[type=checkbox][data-group]"),
      function (cb) { if (cb.checked) wanted[cb.dataset.group] = true; });

    // 按组聚合要建/追加的歌
    var plan = {};
    auData.forEach(function (d) {
      if (!wanted[d.group]) return;
      if (!plan[d.group]) plan[d.group] = [];
      plan[d.group].push(d.name);
    });

    var groupNames = Object.keys(plan);
    if (!groupNames.length) {
      setStatus(auResult, "warn", "没有勾选任何分类。");
      return;
    }

    var btn = $("au-create");
    btn.disabled = true;
    clearStatus(auResult);
    setStatus(auResult, "info",
      "正在处理 " + groupNames.length + " 个分类…（已存在的专辑为追加式）");

    // 依次处理每个组：建歌单 -> 追加歌 -> 写记录
    var stats = [];
    var chain = Promise.resolve();

    groupNames.forEach(function (g) {
      chain = chain.then(function () {
        return apiReq("POST", U.playlistadd, { name: g })
          .catch(function () { return null; })   // 已存在会失败，忽略
          .then(function () {
            return apiReq("POST", U.playlistaddmusic,
              { name: g, music_list: plan[g] });
          })
          .then(function () {
            return apiReq("POST", U.albumSave,
              { album: g, auto: true, songs: plan[g] });
          })
          .then(function () {
            stats.push({ group: g, count: plan[g].length, ok: true });
          })
          .catch(function (err) {
            stats.push({
              group: g, count: plan[g].length, ok: false,
              err: (err && err.notImplemented) ? "后端无 /api/music-mgr/album/save（404），补丁未装"
                : (err && err.message ? err.message : "失败")
            });
          });
      });
    });

    chain.then(function () {
      paintCreateResult(stats);
      var ok = stats.filter(function (s) { return s.ok; }).length;
      setStatus(auResult, ok === stats.length ? "ok" : "warn",
        "完成：" + ok + "/" + stats.length + " 个分类已创建/追加。"
        + "如界面没更新，可到「专辑管理」点刷新。");
    }).then(function () {
      btn.disabled = false;
    });
  }

  function paintCreateResult(stats) {
    auResult.innerHTML = "";
    var ul = el("ul", "mm-list");
    stats.forEach(function (s) {
      var li = el("li", "mm-item");
      var row = el("div", "mm-song");
      row.appendChild(el("span", "mm-song-name", s.group));
      row.appendChild(el("span", "mm-meta",
        s.ok ? ("已处理 " + s.count + " 首") : ("失败：" + s.err)));
      li.appendChild(row);
      ul.appendChild(li);
    });
    auResult.appendChild(ul);
    auResult.hidden = false;
  }

  $("au-analyze").addEventListener("click", analyze);
  $("au-selall").addEventListener("click", function () { setAllGroups(true); });
  $("au-selnone").addEventListener("click", function () { setAllGroups(false); });
  $("au-create").addEventListener("click", createSelected);

  /* ==================== 高级设置：专辑记录 ==================== */

  var modal = $("mm-settings");
  var stStatus = $("st-status");

  function openSettings() {
    modal.hidden = false;
    loadRecords();
  }
  function closeSettings() { modal.hidden = true; }

  function loadRecords() {
    clearStatus(stStatus);
    var body = $("st-body");
    body.innerHTML = "";
    var trLoad = el("tr");
    var tdLoad = el("td", "", "加载中…");
    tdLoad.colSpan = 6;
    trLoad.appendChild(tdLoad);
    body.appendChild(trLoad);

    apiReq("GET", U.albums).then(function (data) {
      var recs = (data && data.albums) || [];
      body.innerHTML = "";
      if (!recs.length) {
        var tr0 = el("tr");
        var td0 = el("td", "", "暂无记录。用「自动分类」创建专辑后会在这里出现。");
        td0.colSpan = 6;
        tr0.appendChild(td0);
        body.appendChild(tr0);
        return;
      }
      recs.forEach(function (r) {
        var tr = el("tr");
        tr.appendChild(el("td", "", r.album || "-"));
        tr.appendChild(el("td", "", r.auto ? "自动" : "手动"));
        tr.appendChild(el("td", "", String((r.songs || []).length)));
        tr.appendChild(el("td", "", r.created || "-"));
        tr.appendChild(el("td", "", r.file || "-"));

        var tdAct = el("td");
        var del = el("button", "mm-btn", "删除记录");
        del.type = "button";
        del.title = "只删记录文件，不删歌单、不删音频";
        del.addEventListener("click", function () {
          if (!window.confirm("删除「" + r.album + "」的记录？\n只删记录文件，不影响歌单与音频文件。")) return;
          apiReq("POST", U.albumDelete, { album: r.album, delete_playlist: false })
            .then(function () { loadRecords(); })
            .catch(function (err) { handleErr(stStatus, err, loadRecords, U.albumDelete); });
        });
        tdAct.appendChild(del);

        var delAll = el("button", "mm-btn", "删记录+歌单");
        delAll.type = "button";
        delAll.title = "删记录文件，并删除同名歌单（不含音频文件）";
        delAll.style.marginLeft = "4px";
        delAll.addEventListener("click", function () {
          if (!window.confirm("删除「" + r.album + "」的记录并删除同名歌单？\n专辑里的音频文件不会被删除。")) return;
          apiReq("POST", U.albumDelete, { album: r.album, delete_playlist: true })
            .then(function () { loadRecords(); })
            .catch(function (err) { handleErr(stStatus, err, loadRecords, U.albumDelete); });
        });
        tdAct.appendChild(delAll);
        tr.appendChild(tdAct);

        body.appendChild(tr);
      });
    }).catch(function (err) {
      body.innerHTML = "";
      handleErr(stStatus, err, loadRecords, U.albums);
    });
  }

  $("mm-gear").addEventListener("click", openSettings);
  $("st-close").addEventListener("click", closeSettings);
  $("st-reload").addEventListener("click", loadRecords);
  modal.addEventListener("click", function (e) {
    if (e.target === modal) closeSettings();
  });

  /* ==================== 初始化 ==================== */
  // 进页面只加载重命名列表（最常用），其余按需加载，避免无谓请求。
  loadSongs();
})();
